<!doctype html>
<html lang="en">
  <head>
<!--meta-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="She (is Your) Virtual Assistant">
    <meta name="author" content="ilham 513">
	<link rel="apple-touch-icon" sizes="180x180" 	href="../icon/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../icon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../icon/favicon-16x16.png">
	<link rel="manifest" 							href="../icon/site.webmanifest">
	<link rel="icon" 								href="http://sheva.my.id/icon/favicon.ico">
<!--meta END-->
    <title>Sheva Dagelan</title>

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:700,900" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/4.0/examples/blog/blog.css" rel="stylesheet">
  </head>

  <body>

    <div class="container">
      <header class="blog-header py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
          <div class="col-4 pt-1">
            <a class="text-muted" href="#">Subscribe</a>
          </div>
          <div class="col-4 text-center">
            <a class="blog-header-logo text-dark" href="#">Sheva</a>
          </div>
          <div class="col-4 d-flex justify-content-end align-items-center">
            <a class="text-muted" href="#">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-3"><circle cx="10.5" cy="10.5" r="7.5"></circle><line x1="21" y1="21" x2="15.8" y2="15.8"></line></svg>
            </a>
            <a class="btn btn-sm btn-outline-secondary" href="#">Login</a>
          </div>
        </div>
      </header>

      <div class="nav-scroller py-1 mb-2">
        <nav class="nav d-flex justify-content-between">
          <a class="p-2 text-muted" href="#">Teknologi </a>
          <a class="p-2 text-muted" href="#">Desain </a>
          <a class="p-2 text-muted" href="#">Budaya </a>
          <a class="p-2 text-muted" href="#">Bisnis </a>
          <a class="p-2 text-muted" href="#">Politik </a>
          <a class="p-2 text-muted" href="#">Opini </a>
          <a class="p-2 text-muted" href="#">Sains </a>
          <a class="p-2 text-muted" href="#">Kesehatan </a>
          <a class="p-2 text-muted" href="#">Gaya </a>
          <a class="p-2 text-muted" href="#">Meme </a>
        </nav>
      </div>
	  
<!-- Page Content -->
<div class="container">

  <!-- Page Heading -->
  <h1 class="my-4">Artikel Terbaru
    <small>(<? echo date("Y-m-d") ?>)</small>
  </h1>


  <div class="row">
	
	
	
<?php include_once('config.php');

$sql = "SELECT * FROM $table_name LIMIT 6";
$result = $conn->query($sql);

while($row = $result->fetch_array()) {

echo '  
		<div class="col-lg-6 mb-4">
		  <div class="card h-100">
			<a href="artikel/?id='.$row['id'].'"><img class="card-img-top" src="'.$row['gambar'].'" width="700" height="400" alt=""></a>
			<div class="card-body">
			  <h4 class="card-title">
				<a href="artikel/?id='.$row['id'].'">'.$row['judul'].'</a>
			  </h4>
			  <p class="card-text">'.substr((strip_tags($row['artikel'])),0,900).'...
			  <a href="artikel/?id='.$row['id'].'">Baca Selengkapnya</a>
			  </p>
			</div>
		  </div>
		</div>

  ';
}
?>	  
	  
	  
	  
	  
	  
  </div>
</div>  
<!-- Page Content END -->	  
	  
	  
	  
	  
	  
	  




    <footer class="blog-footer">
      <p>
        <a href="#">Kembali Ke Atas</a>
      </p>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>
  </body>
</html>
